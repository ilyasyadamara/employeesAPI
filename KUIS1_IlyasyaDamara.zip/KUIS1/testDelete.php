<?php
include_once(__DIR__."/lib/Employees.php");
include_once(__DIR__."/lib/format_data.php");
header("Access-Control-Allow-Origin:*");

$employees = new Employees();
$employees->setValue('E0002','Ilyas','Damara','ilyasya.damara12@gmail.com','0895363632712','2019-10-04','001','3000000', 'Network', '001', '001');
$result=$employees->delete();
$format= new format_data();
echo $format->as_JSON($result);